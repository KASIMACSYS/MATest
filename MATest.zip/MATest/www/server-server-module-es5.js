(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["server-server-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/server/server.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/server/server.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"home\">\n  <div >\n   \n  <br> <br> <br> <br> <br> <br><br>  \n  \n  <!-- <div> <img  src=\"./assets/img/Front2.jpg\"  /></div>-->\n  <div class=\"ion-padding\"> \n      <ion-input [(ngModel)]=\"serverip\" type=\"text\" placeholder=\"serverIP\" class=\"ion-item\" ></ion-input>\n      <ion-input [(ngModel)]=\"companyid\" type=\"text\" placeholder=\"companyID\" class=\"ion-item\"></ion-input>\n    \n    <!-- <div padding> -->\n        <ion-button expand=\"block\" small  color=\"light\"  menuToggle (click)=\"settings()\">Next</ion-button>\n        \n      <!-- <ion-button class=\"button-native\" color=\"primary\" menuToggle (click)=\"settings()\">Next</ion-button> -->\n    <!-- </div> -->\n    \n  </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/server/server.module.ts":
/*!*****************************************!*\
  !*** ./src/app/server/server.module.ts ***!
  \*****************************************/
/*! exports provided: ServerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServerPageModule", function() { return ServerPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _server_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./server.page */ "./src/app/server/server.page.ts");







var routes = [
    {
        path: '',
        component: _server_page__WEBPACK_IMPORTED_MODULE_6__["ServerPage"]
    }
];
var ServerPageModule = /** @class */ (function () {
    function ServerPageModule() {
    }
    ServerPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_server_page__WEBPACK_IMPORTED_MODULE_6__["ServerPage"]]
        })
    ], ServerPageModule);
    return ServerPageModule;
}());



/***/ }),

/***/ "./src/app/server/server.page.scss":
/*!*****************************************!*\
  !*** ./src/app/server/server.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NlcnZlci9zZXJ2ZXIucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/server/server.page.ts":
/*!***************************************!*\
  !*** ./src/app/server/server.page.ts ***!
  \***************************************/
/*! exports provided: ServerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServerPage", function() { return ServerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var ServerPage = /** @class */ (function () {
    function ServerPage(router) {
        this.router = router;
    }
    ServerPage.prototype.ngOnInit = function () {
    };
    ServerPage.prototype.settings = function () {
        var conObj = { serverIP: '', webLink: '', companyID: '' };
        conObj.serverIP = this.serverip;
        conObj.webLink = 'http://' + this.serverip + '/acSysERPMA/';
        // conObj.webLink= 'http://localhost:50344/';
        conObj.companyID = this.companyid;
        localStorage.removeItem('conObj');
        localStorage.setItem('conObj', JSON.stringify(conObj));
        // console.log('Local Storage : '+ JSON.stringify(conObj))
        this.router.navigate(['/login']);
    };
    ServerPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    ServerPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-server',
            template: __webpack_require__(/*! raw-loader!./server.page.html */ "./node_modules/raw-loader/index.js!./src/app/server/server.page.html"),
            styles: [__webpack_require__(/*! ./server.page.scss */ "./src/app/server/server.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], ServerPage);
    return ServerPage;
}());



/***/ })

}]);
//# sourceMappingURL=server-server-module-es5.js.map