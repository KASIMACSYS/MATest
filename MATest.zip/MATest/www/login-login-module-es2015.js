(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html":
/*!*****************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <br>  \n  <!-- <ion-item> \n      \n  </ion-item> -->\n  <ion-icon item-right class=\"icon ion-md-settings\" (click)=\"serverPage()\" ></ion-icon> \n \n   <br> <br> <br> <br> <br><br> \n  <!-- <div align=\"center\" > <img  src=\"./assets/img/Person.jpg\"  /></div> -->\n\n  <div class=\"ion-padding\"> \n      <ion-input [(ngModel)]=\"username\" type=\"text\" placeholder=\"Username\" class=\"ion-item\" ></ion-input>\n      <ion-input  [(ngModel)]=\"password\" type=\"password\" placeholder=\"Password\" class=\"ion-item\" ></ion-input>\n      <ion-button expand=\"block\" small  color=\"light\"  menuToggle (click)=\"login()\">Login</ion-button> \n      <ion-input  [(ngModel)]=\"erroralert\" type=\"text\" style=\"color: orange\"></ion-input>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/login-data.service.ts":
/*!***************************************!*\
  !*** ./src/app/login-data.service.ts ***!
  \***************************************/
/*! exports provided: LoginDataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginDataService", function() { return LoginDataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LoginDataService = class LoginDataService {
    constructor() { }
};
LoginDataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], LoginDataService);



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
let LoginPageModule = class LoginPageModule {
};
LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _login_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login-data.service */ "./src/app/login-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






let LoginPage = class LoginPage {
    constructor(router, loadingController, _http, param) {
        this.router = router;
        this.loadingController = loadingController;
        this._http = _http;
        this.param = param;
        this.username = '';
        this.password = '';
    }
    ngOnInit() {
    }
    login() {
        this.erroralert = '';
        alert('test : ');
        this.showLoading();
        if (this.username != '' && this.password != '') {
            let tempconObj = { serverIP: '', webLink: '', companyID: '' };
            tempconObj = JSON.parse(localStorage.getItem('conObj')) || tempconObj;
            let data = { 'siteID': tempconObj.companyID, 'strEmpID': this.username, 'strPassword': this.password };
            let url = tempconObj.webLink + 'Common.asmx/UserValidate';
            console.log('login1 url : ' + url);
            // console.log('data : ' + JSON.stringify(data));
            this._http.post(url, data, {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                    'Content-Type': 'application/json'
                })
            })
                // .catch(this.handleError)
                // .pipe(map(res => res))  
                // .pipe(catchError(this.handleError)) 
                .subscribe((data) => {
                this.param.data = data;
                alert('d : ' + this.param.data.d);
                console.log('login data : ' + JSON.parse(this.param.data.d));
                this.loginDetails = JSON.parse(this.param.data.d);
                if (this.loginDetails.ErrorNo === 0) {
                    // var a = JSON.parse(this.param.data.d); 
                    // console.log('Login data ' + JSON.stringify(a));  
                    console.log('Login success');
                    alert('Login success');
                    // this.router.navigate(["/dashboard"] );
                }
                else {
                    console.log('Login fail');
                    this.erroralert = JSON.stringify(this.loginDetails.ErrorMsg);
                }
            }, err => {
                this.erroralert = 'Please Enter Valid Data...' + JSON.stringify(this.loginDetails.ErrorMsg);
                ///console.log("Error!:", err.json());
            });
        }
        else {
            this.erroralert = 'Please Enter Username/Password';
        }
    }
    showLoading() {
        this.loadingController.create({
            message: 'Please wait...',
            duration: 2000
        }).then(loading => loading.present());
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _login_data_service__WEBPACK_IMPORTED_MODULE_4__["LoginDataService"] }
];
LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: __webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html"),
        styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _login_data_service__WEBPACK_IMPORTED_MODULE_4__["LoginDataService"]])
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map