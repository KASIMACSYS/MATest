import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { LoginDataService } from '../login-data.service';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  public username='';
  public password=''; 
  data;
  error;
  erroralert:any;
  loginDetails:any;
  
  constructor(
    private router : Router,
    private loadingController: LoadingController,  
    private _http : HttpClient,
    private param: LoginDataService
    ) 
  { }

  ngOnInit() {
  }

  login(){
    this.erroralert='';
    alert('test : ');
    this.showLoading();
    if(this.username!='' && this.password!=''){
      let tempconObj = {serverIP : '', webLink : '', companyID: ''};
      tempconObj = JSON.parse( localStorage.getItem('conObj')) || tempconObj;
      let data= {'siteID': tempconObj.companyID , 'strEmpID':this.username, 'strPassword': this.password};
      
      // let url = tempconObj.webLink + 'Common.asmx/UserValidate';
      let url = 'http://192.168.1.8/acSysERPMA/Common.asmx/UserValidate';
      console.log('login1 url : ' + url);
      // console.log('data : ' + JSON.stringify(data));
      this._http.post(url,data,{
        headers : new HttpHeaders({
          'Content-Type': 'application/json' 
        })
      })  
      // .catch(this.handleError)
      // .pipe(map(res => res))  
      // .pipe(catchError(this.handleError)) 
      .subscribe((data)=>{    
        this.param.data = data;
        alert('d : '+ this.param.data.d);
        console.log('login data : ' + JSON.parse( this.param.data.d));
        this.loginDetails = JSON.parse( this.param.data.d);   

        if(this.loginDetails.ErrorNo===0)
        {
          // var a = JSON.parse(this.param.data.d); 
            // console.log('Login data ' + JSON.stringify(a));  
            console.log('Login success');   
            alert('Login success');    
            // this.router.navigate(["/dashboard"] );
        }
        else
        {
          console.log('Login fail'); 
          this.erroralert=JSON.stringify(this.loginDetails.ErrorMsg);
        }
      } , err=>{
        this.erroralert='Please Enter Valid Data...'+JSON.stringify(this.loginDetails.ErrorMsg);
        ///console.log("Error!:", err.json());
      })
    }
    else
    {
      this.erroralert='Please Enter Username/Password';
    }
    
    
  }

  showLoading() {
    this.loadingController.create({
      message: 'Please wait...',
      duration: 2000      
    }).then(loading => loading.present());
  }
}
