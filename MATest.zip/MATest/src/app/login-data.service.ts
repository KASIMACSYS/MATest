import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginDataService {
  data;
  pages;
  public text: String;
  public format: String;
  constructor() { }
}
