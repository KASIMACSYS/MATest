import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-server',
  templateUrl: './server.page.html',
  styleUrls: ['./server.page.scss'],
})
export class ServerPage implements OnInit {
  public serverip;
  public companyid;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  settings(){
    let conObj = {serverIP : '', webLink : '', companyID: ''};
    conObj.serverIP= this.serverip;
    conObj.webLink= 'http://'+this.serverip+'/acSysERPMA/';
    // conObj.webLink= 'http://localhost:50344/';
    conObj.companyID= this.companyid;
    localStorage.removeItem('conObj');
    localStorage.setItem('conObj',JSON.stringify(conObj));   
    // console.log('Local Storage : '+ JSON.stringify(conObj))
    this.router.navigate(['/login']);
  }
}
